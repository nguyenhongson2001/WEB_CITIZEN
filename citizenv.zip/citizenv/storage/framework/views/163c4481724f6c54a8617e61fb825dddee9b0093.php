<?php for($i = 0; $i < sizeof($searchresults); $i++): ?>
    <tr>
        <td data-label="STT"><?php echo e($i + 1); ?></td>
        <td data-label="Họ và tên"><?php echo e($searchresults[$i]->name); ?></td>
        <td data-label="Ngày sinh"><?php echo e($searchresults[$i]->dob); ?></td>
        <td data-label="Giới tính"><?php echo e($searchresults[$i]->gender); ?></td>
        <td data-label="Công việc"><?php echo e($searchresults[$i]->job); ?></td>
        <td data-label="Chi tiết" id="<?php echo e($searchresults[$i]->stt); ?>"><a class="dialog-btn" href="#my-dialog" onclick="getpersondetail(this)">Xem thêm</td>                                        
    </tr>
<?php endfor; ?><?php /**PATH E:\xampp\htdocs\citizenv\resources\views/content/searchlist.blade.php ENDPATH**/ ?>