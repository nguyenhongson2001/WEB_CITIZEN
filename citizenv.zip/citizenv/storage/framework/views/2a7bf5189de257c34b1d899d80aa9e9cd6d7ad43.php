<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="<?php echo e(asset('template/css/styleweb.css')); ?>">
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.6.2/dist/chart.min.js"></script>
        <link rel="stylesheet" href="<?php echo e(asset('template/css/stylesider.css')); ?>">
    </head>
<body>
    <div class="page-wrapper">
        <input type="checkbox" name="" id="menu-toggle">

        <div class="sidebar">
            <div class="brand">
                <h3>
                    <span class="lab la-untappd"></span> 
                    CitizenV
                </h3>
            </div>

            <div class="profile-card">
                <div class="profile-img" style="background-image: url('<?php echo e(asset('template/images/yte_logo.png')); ?>')"></div>
                <div class="profile-info">
                    <h2>Heather Parker</h2>
                    <small>Web Architect</small>
                </div>
                <div class="profile-action">
                    <a href="" class="btn btn-white">
                        <span class="las la-coins"></span>
                        $2,300
                    </a>
                </div>
                <div class="profile-icons">
                    <span class="las la-user"></span>
                    <span class="las la-comment-alt"></span>
                    <span class="las la-file-invoice"></span>
                </div>
            </div>

            <div class="sidebar-menu">
                <div class="menu-item">
                    <a href="#" class="active" onclick="opensidebar(event, 'home')">
                        <span class="las la-home"></span>
                        <span>Trang chủ</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'taotaikhoan')">
                        <span class="las la-project-diagram"></span>
                        <span> Tạo Tài khoản</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'danhsachtp')">
                        <span class="las la-tasks"></span>
                        <span>Danh sách TP</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'taomatp')">
                        <span class="las la-columns"></span>
                        <span>Tạo mã TP</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'phantichdanso')">
                        <span class="las la-users-cog"></span>
                        <span>Phân tích</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'nhapthongtin')">
                        <span class="las la-user-ninja"></span>
                        <span>Nhập thông tin</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#">
                        <span class="las la-file-invoice"></span>
                        <span>Invoices</span> 
                    </a>
                </div>
                <div class="menu-item">
                    <a href="#" onclick="opensidebar(event, 'doimatkhau')">
                        <span class="las la-cogs"></span>
                        <span>Đổi mật khẩu</span> 
                    </a>
                </div>
            </div>

            <div class="sidebar-card">
                <h2>Xin chào</h2>
                <p>Bạn muốn đăng xuất khỏi hệ thống?</p>
                
                <a href="/logout" class="btn btn-block btn-white">Đăng xuất</a>
            </div>
        </div>

        <div class="main-content">
            <header>
                <label for="menu-toggle">
                    <span class="las la-bars"></span>
                </label>

                <div class="head-icons">
                    <span class="las la-search"></span>
                    <span class="las la-comment-alt"></span>
                    <span class="las la-bell"></span>
                    <div class="head-avatar">
                        <div class="avatar" style="background-image: url('<?php echo e(asset('template/images/user_logo.jpg')); ?>')"></div>
                        <span>John Snow</span>
                    </div> 
                </div>
            </header>

            <main>
                <div class="page-header">
                    <h1>Chào mừng bạn</h1>
                    <small>đã đến Hệ thống điều tra dân số</small>
                </div>

                <div id="home" class="tabcontent">
                    <div class="analytics">
                        <div class="card engage-card">
                            <div class="card-head">
                                Engagement
                            </div>
                            <div class="card-body">
                                <div class="slideshow-container">

                                    <div class="mySlides fade">
                                        <div class="numbertext">1 / 3</div>
                                        <img src="<?php echo e(asset('template/images/img1.jpg')); ?>" style="width:100%">
                                        <div class="text">Caption Text</div>
                                    </div>
                            
                                    <div class="mySlides fade">
                                        <div class="numbertext">2 / 3</div>
                                        <img src="<?php echo e(asset('template/images/img2.jpg')); ?>" style="width:100%">
                                        <div class="text">Caption Two</div>
                                    </div>
                            
                                    <div class="mySlides fade">
                                        <div class="numbertext">3 / 3</div>
                                        <div class="chart-wrapper">
                                            <div id="chart"></div>
                                        </div>
                                        <div class="text">Caption Three</div>
                                    </div>
                            
                                    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                                    <a class="next" onclick="plusSlides(1)">&#10095;</a>
                            
                                </div>
                                <br>
                            
                                <div style="text-align:center">
                                    <span class="dot" onclick="currentSlide(1)"></span>
                                    <span class="dot" onclick="currentSlide(2)"></span>
                                    <span class="dot" onclick="currentSlide(3)"></span>
                                </div>
                                <script src="<?php echo e(asset('template/js/siderjs.js')); ?>"></script>
                            </div>
                        </div>
                        <div class="card  emails-card">
                            <div class="card-head">
                                Email sent
                            </div>
                            <div class="card-body">
                                <div id="emailChart"></div>
                            </div>
                            <div class="card-footer">
                                <div class="emails-info">
                                    <div class="email-stat">
                                        <span class="status bg-danger"></span>
                                        <span>30 not sent</span>
                                    </div>
                                    <div class="email-stat">
                                        <span class="status bg-warning"></span>
                                        <span>38 opened</span>
                                    </div>
                                    <div class="email-stat">
                                        <span class="status bg-success"></span>
                                        <span>68 sucess</span>
                                    </div>
                                    <div class="email-stat">
                                        <span class="status bg-danger"></span>
                                        <span>SMTP error</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    
                    <div class="grid-2">
                        <div class="card team-progress">
                            <div class="card-head">
                                <div class="team-head">
                                    <div>
                                        <h3>Team Progress</h3>
                                        <small>890, 344 saldes</small>
                                    </div>
                                    <select name="" id="">
                                        <option value="">User</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-body">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Author</th>
                                            <th>Company</th>
                                            <th width="22%">Progress</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="team-info">
                                                    <div class="team-img">
                                                        <img src="<?php echo e(asset('template/images/11.svg')); ?>" alt="">
                                                    </div>
                                                    <div class="team-details">
                                                        <h4>Bread Simons</h4>
                                                        <small>HTML, JS, React JS</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="company-info">
                                                    <h4>Interco</h4>
                                                    <small>Web UI/UX Design</small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="team-progress">
                                                    <h4>65%</h4>
                                                    <div class="progress-bar">
                                                        <div class="indicator success" style="width: 55%">
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="" class="btn btn-main">View</a>
                                            </td>
                                        </tr>
                
                                        <tr>
                                            <td>
                                                <div class="team-info">
                                                    <div class="team-img">
                                                        <img src="<?php echo e(asset('template/images/11.svg')); ?>" alt="">
                                                    </div>
                                                    <div class="team-details">
                                                        <h4>Bread Simons</h4>
                                                        <small>HTML, JS, React JS</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="company-info">
                                                    <h4>Interco</h4>
                                                    <small>Web UI/UX Design</small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="team-progress">
                                                    <h4>65%</h4>
                                                    <div class="progress-bar">
                                                        <div class="indicator success" style="width: 65%">
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="" class="btn btn-main">View</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                
                        <div class="card competitors">
                            <div class="card-head">
                                <h4>My Competitors</h4>
                                <small>More than 400+ new members</small>
                            </div>
                            <div class="card-body">
                                <div class="compete-info">
                                    <div>
                                        <img src="" alt="">
                                    <div class="compete-details">
                                        <h4>Cup & Green</h4>
                                        <small>Study highway types</small>
                                        <p>By: <a href="">Code resource</a></p>
                                    </div>
                                    </div>
                                    <div class="compete-sales">
                                        <h3>24,900</h3>
                                        <small>Sales</small>
                                    </div>
                                </div>
                                <div class="compete-info">
                                    <div>
                                        <img src="" alt="">
                                    <div class="compete-details">
                                        <h4>Cup & Green</h4>
                                        <small>Study highway types</small>
                                        <p>By: <a href="">Code resource</a></p>
                                    </div>
                                    </div>
                                    <div class="compete-sales">
                                        <h3>24,900</h3>
                                        <span>Sales</span>
                                    </div>
                                </div>
                                <div class="compete-info">
                                    <div>
                                        <img src="" alt="">
                                    <div class="compete-details">
                                        <h4>Cup & Green</h4>
                                        <small>Study highway types</small>
                                        <p>By: <a href="">Code resource</a></p>
                                    </div>
                                    </div>
                                    <div class="compete-sales">
                                        <h3>24,900</h3>
                                        <span>Sales</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="taotaikhoan" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">TẠO TÀI KHOẢN</div>
                            <div class="content">
                                <form action="#">
                                    <div class="user-details">
                                            
                                            <div class="input-group2  reponsive-form">
                                            <div class="input-details row-group2">
                                                <span class="details">Tài khoản mới</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mât khẩu</span>
                                                <input type="password" placeholder="" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="button">
                                        <input type="submit" value="Xác Nhận">
                                    </div>
                                </form>
                            </div>
                        </div> 
                        </div>
                </div>
    
                <div id="danhsachtp" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="content">
                                <form action="#">
                                    <div class="user-details">     
                                            <div class="listcity ">
                                                <span class="details listcity-name">Danh sách TP</span>
                                                <div class="button-listcity">
                                                    <input class="button-listcity-box" type="text" placeholder="Tìm kiếm TP" required>
                                                    <input class="button-listcity-search" type="submit" value="Xác Nhận">
                                                </div>
                                            </div>
                                    </div>
                                </form>
                            </div>
                        </div> 
                        </div>
                </div>
    
                <div id="taomatp" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">TẠO MÃ CHO THÀNH PHỐ</div>
                            <div class="content">
                                <form action="#">
                                    <div class="user-details"> 
                                            <div class="input-group2 reponsive-form">
                                            <div class="input-details row-group2">
                                                <span class="details">Thành phố</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mã Thành phố</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="button">
                                        <input type="submit" value="Xác Nhận">
                                    </div>
                                </form>
                            </div>
                        </div> 
                        </div>
                </div>
    
                <div id="doimatkhau" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">Đổi mật khẩu</div>
                            <div class="content">
                                <form action="#">
                                    <div class="user-details"> 
                                            <div class="input-group">
                                            <div class="input-details row-group2">
                                                <span class="details">Mật khẩu cũ</span>
                                                <input type="password" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mât khẩu mới</span>
                                                <input type="password" placeholder="" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="button">
                                        <input type="submit" value="Xác Nhận">
                                    </div>
                                </form>
                            </div>
                        </div> 
                        </div>
                </div>
    
                <div id="phantichdanso" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="all-buttonchart">
                                <a href="#" class="buttonchart">
                                    <div class="buttonchart-icon">
                                        <img src="<?php echo e(asset('template/images/chartbar.png')); ?>" alt="">
                                        <p>Cột</p>
                                    </div>   
                                    </a>
                                    <a href="#" class="buttonchart">
                                        <div class="buttonchart-icon">
                                            <img src="<?php echo e(asset('template/images/chartpie.png')); ?>" alt="">
                                            <p>Tròn</p>
                                        </div>   
                                    </a>
                                    <a href="#" class="buttonchart">
                                        <div class="buttonchart-icon">
                                            <img src="<?php echo e(asset('template/images//chartline (1).png')); ?>" alt="">
                                            <p>Đường</p>
                                        </div>   
                                    </a>
                                    <a href="#" class="buttonchart">
                                        <div class="buttonchart-icon">
                                            <img src="<?php echo e(asset('template/images/chartkethop.png')); ?>" alt="">
                                            <p>kết hợp</p>
                                        </div>   
                                    </a>
                            </div>   
                        </div>
                    </div>
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">PHÂN TÍCH DÂN SỐ</div>
                            <form action="#">
                                <div class="selectpeople">
                                    <div class="select-country nameselect">
                                        <p>Toàn quốc</p>
                                        <select>
                                            <option>- Chọn toàn quốc -</option>
                                        </select>
                                    </div>
                                    <div class="select-city nameselect">
                                        <p>Tỉnh/ TP</p>
                                        <select>
                                            <option>- Chọn tỉnh/ TP -</option>
                                            <option>Danh sách 01</option>
                                            <option>Danh sách 02</option>
                                            <option>Danh sách 03</option>
                                            </select>
                                    </div>
                                    <div class="select-district nameselect">
                                        <p>Quận/ huyện</p>
                                        <select>
                                            <option>- Chọn huyện -</option>
                                            <option>Danh sách 02</option>
                                            <option>Danh sách 03</option>
                                            <option>Danh sách 03</option>
                                            </select>
                                    </div>
                                    <div class="select-wards nameselect">
                                        <p>Phường/ Xã</p>
                                        <select>
                                            <option>- Chọn xã/ phường -</option>
                                            <option>Danh sách 02</option>
                                            <option>Danh sách 03</option>
                                            <option>Danh sách 03</option>
                                            </select>
                                    </div>
                                    <div class="select-village nameselect">
                                        <p>Thôn/ Xóm</p>
                                        <select>
                                            <option>- Chọn thôn/ xóm -</option>
                                            <option>Danh sách 02</option>
                                            <option>Danh sách 03</option>
                                            <option>Danh sách 03</option>
                                            </select>
                                    </div>
                                </div>
                                <div class="button">
                                    <input type="submit" value="Xác Nhận">
                                </div>
                            </form>
                            <div class="chartpeople">
                                <div class="chart-chartbar chart">
                                    <div class="chartbar">
                                        <canvas id="myChartbar1" width="200" height="200"></canvas>
                                    </div>
                                    <div class="chartbar">
                                        <canvas id="myChartbar2" width="200" height="200"></canvas>
                                    </div>  
                                </div>
                                <div class="chart-chartpie chart">
                                    <div class="chartpie">
                                        <canvas id="myChartpie" width="200" height="200"></canvas>
                                    </div>
                                </div>
                                <div class="chart-line chart">
                                    <canvas id="myChartline" width="200" height="200"></canvas>
                                </div>
                                <div class="chart-combo chart">
                                    <canvas id="myChartcombo" width="200" height="200"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div id="nhapthongtin" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">THÔNG TIN CÁ NHÂN</div>
                            <div class="content">
                                <form action="#">
                                    <div class="user-details">
                                        <div class="input-group2 reponsive-form">
                                            <div class="input-details row-group2">
                                                 <span class="details ">Họ tên</span>
                                                 <input type="text" class="" placeholder="" required>
                                            </div>
                                            <div class="input-detail row-group2 ">
                                                 <span class="details">Giới tính</span>
                                                <div class="radio-group">
                                                     <label >
                                                         <input type="radio" value="nam" name="gender">
                                                         <p>Nam</p>
                                                     </label>
                                                     <label >
                                                         <input type="radio" value="nu" name="gender">
                                                         <p>Nữ</p>
                                                         
                                                     </label>
                                                     <label >
                                                         <input type="radio" value="khac" name="gender">
                                                         <p>Khác</p>
                                                     </label>
                                                </div>
                                            </div>
                                        </div>
                                          <div class="input-group3 reponsive-form">
                                                <div class="input-details row-group3">
                                                 <span class="details ">Ngày sinh</span>
                                                 <input type="date" placeholder="" required min="1900-01-01" max="2021-12-31">
                                                 
                                                </div>
                                                <div class="input-details row-group3">
                                                 <span class="details ">CMND / CCCD</span>
                                                 <input type="text" class="" placeholder="" required>
                                                </div> 
                                                <div class="input-details row-group3">
                                                 <span class="details ">Quốc tịch</span>
                                                 <input class="" type="text" placeholder="" required>
                                                </div>
                                         </div>
                                         <div class="input-group2  reponsive-form">
                                            <div class="input-details row-group2">
                                                <span class="details">Mã thành phố (thường trú)</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mã quận/huyện (thường trú)</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                        </div>
                                        <div class="input-group2  reponsive-form">
                                            <div class="input-details row-group2">
                                                <span class="details">Mã xã/phường (thường trú)</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mã thôn (thường trú)</span>
                                                <input type="text" placeholder="" required>
                                            </div>
                                        </div>
                                        <div class="input-group3 reponsive-form">
                                            <div class="input-details row-group3">
                                             <span class="details ">Công việc</span>
                                             <input type="text" class="" placeholder="" required>
                                             
                                            </div>
                                            <div class="input-details row-group3">
                                             <span class="details ">Tôn giáo</span>
                                             <input type="text" class="" placeholder="" required>
                                            </div> 
                                            <div class="input-details row-group3">
                                             <span class="details ">Trình độ</span>
                                             <input class="" type="text" placeholder="" required>
                                            </div>
                                     </div>
                                     <div class="input-group3 reponsive-form">
                                        <div class="input-details row-group3">
                                         <span class="details ">Mã thành phố (tạm trú)</span>
                                         <input type="text" class="" placeholder="" required>
                                        </div>
                                        <div class="input-details row-group3">
                                         <span class="details ">Mã quận/huyện (tạm trú)</span>
                                         <input type="text" class="" placeholder="" required>
                                        </div> 
                                        <div class="input-details row-group3">
                                         <span class="details ">Mã xã/phường (tạm trú)</span>
                                         <input class="" type="text" placeholder="" required>
                                        </div>
                                 </div>
                                        
                                    </div>
                                    
                                    <div class="button">
                                        <input type="submit" value="GỬI">
                                    </div>
                                </form>
                            </div>
                        </div> 
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script>
        //Chart
        let options = {
            chart: {
                type: 'line',
                height: "280px",
                fontFamily: "Nunito",
                toolbar: {
                    show: false,
                }
            },
            stroke: {
                curve: "smooth",
                width: 8,
                colors: ["#6E00FF"],
            },
            marker: {
                size: 7,
                colors: ["#6E00FF"],

            },
            grid: {
                strokeDashArray: 10,
            },
            series: [{
                name: 'engagement',
                data: [5, 3, 10, 8, 29, 19, 22]
            }],
            xaxis: {
                categories: ["Feb","Mar", "Apr", "May", "Jun","Jul","Aug"]
            }
        }
            var chart = new ApexCharts(document.querySelector("#chart"), options);
            chart.render();

        // Radial Bar Chart
        let optionsRadial = {
            series: [60],
            chart: {
                height: 250,
                type: 'radialBar',
            },
            plotOptions: {
                radialBar: {
                    hollow: {
                        size: '60%',
                    },
                    dataLabels: {
                        name : {
                            show: false,
                        },
                        value: {
                            formatter: function(val) {
                                return parseInt(val);
                            },
                            color: '#555',
                            fontSize: '36px',
                            fontWeight: 500,
                        }
                    }
                },
            },
            stroke: {
                lineCap:"round",
            },
            fill: {
                colors: ["#FFB100"],
            }
        };
        let chartRadial = new ApexCharts(document.querySelector("#emailChart"), optionsRadial);
        chartRadial.render();

        let menuItems = document.querySelectorAll(".sidebar .menu-item a");
        for (let i = 0; i < menuItems.length; i++) {
            menuItems[i].addEventListener("click", () => {
                for (let j = 0; j < menuItems.length; j++) {
                    if (i == j) {
                        menuItems[i].classList.add("active");
                    } else {
                        menuItems[j].classList.remove("active");
                    }
                }
            })
        }

        //Home-tab
        let tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 1; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }

        // Open Sub-menu
        function opensidebar(event, sub_menu) {
            let tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            document.getElementById(sub_menu).style.display = "block";
        }

// chart
const ctx1 = document.getElementById('myChartbar1');
const myChart1 = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange','Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
                
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
                
            ],
            borderWidth: 1
        }]
    },
    options: {
        indexAxis: 'y',
        scales: {
            x: {
                reverse: true,
                beginAtZero: true
            }
        }
    }
});
const ctx2 = document.getElementById('myChartbar2');
const myChart2 = new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange','Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
                
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
                
            ],
            borderWidth: 1
        }]
    },
    options: {
        indexAxis: 'y',
        
    }
});

// chartpie
const ctx3 = document.getElementById('myChartpie');
const myChart = new Chart(ctx3, {
    type: 'pie',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            hoverOffset: 4
        }]
    },
});

// chart line
const ctx4 = document.getElementById('myChartline');
const myChart4 = new Chart(ctx4, {
    type: 'line',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    },
});

//Chart
const ctx5 = document.getElementById('myChartcombo');
const myChart5 = new Chart(ctx5, {
    type: 'line',
    data: {
        type: 'bar',
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange','Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
                
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
                
            ],
            borderWidth: 1
        }]
    },
    data: {
        type: 'line',
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    },
    options: {
    plugins: {
      title: {
        text: 'Chart.js Combo Time Scale',
        display: true
      }
    },
    scales: {
      x: {
        type: 'time',
        display: true,
        offset: true,
        time: {
          unit: 'day'
        }
      },
    },
  },
});
    </script>
</body>
</html><?php /**PATH E:\xampp\htdocs\citizenv\resources\views/users/home.blade.php ENDPATH**/ ?>