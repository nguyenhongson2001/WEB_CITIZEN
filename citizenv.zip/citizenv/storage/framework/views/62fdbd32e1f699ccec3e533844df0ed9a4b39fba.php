<?php for($i = 0; $i < sizeof($list); $i++): ?>
    <option value="<?php echo e($list[$i]->id); ?>"><?php echo e($list[$i]->name); ?></option>
<?php endfor; ?>
<?php /**PATH E:\xampp\htdocs\citizenv\resources\views/content/namelist.blade.php ENDPATH**/ ?>