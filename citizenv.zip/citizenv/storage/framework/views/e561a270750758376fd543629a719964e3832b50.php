<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf8">
    </head>
    <body>
    <?php echo e($cities); ?>

    </body>
</html>

<?php /**PATH E:\xampp\htdocs\citizenv\resources\views/content/citylist.blade.php ENDPATH**/ ?>