<tr>
    <td >Họ và tên</td>
    <td ><?php echo e($detail->name); ?></td>
  </tr>
  <tr>
     <td >Giới tính</td>
     <td ><?php echo e($detail->gender); ?></td>
   </tr>
   <tr>
     <td >Ngày sinh</td>
     <td ><?php echo e($detail->dob); ?></td>
   </tr>
   <tr>
     <td >CMND/CCCD</td>
     <td ><?php echo e($detail->id); ?></td>
   </tr>
   <tr>
     <td >Quê Quán</td>
     <td ><?php echo e($detail->village . ', ' 
         . $detail->commune . ', '
         . $detail->district .', '
         . $detail->city); ?></td>
   </tr>
   <tr>
     <td >Địa chỉ tạm trú</td>
     <td > <?php if($detail->tempvillage !== null): ?> 
         <?php echo e($detail->tempvillage . ', ' 
         . $detail->tempcommune . ' '
         . $detail->tempdistrict .', '
         . $detail->tempcity); ?> 
        <?php endif; ?>
     </td>
   </tr>
   <tr>
     <td>Tôn giáo</td>
     <td><?php echo e($detail->tongiao); ?></td>
   </tr>
   <tr>
     <td >Trình độ văn hoá</td>
     <td ><?php echo e($detail->culturelevel); ?></td>
   </tr>
   <tr>
     <td >Nghề nghiệp</td>
     <td ><?php echo e($detail->job); ?></td>
</tr> <?php /**PATH E:\xampp\htdocs\citizenv\resources\views/content/persondetail.blade.php ENDPATH**/ ?>