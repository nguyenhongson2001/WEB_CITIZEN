                <div id="doimatkhau" class="tabcontent" style="display: none;">
                    <div class="formcontent">
                        <div class="container">
                            <div class="title">Đổi mật khẩu</div>
                            <div class="content">
                                <form action="#">
                                    <div class="user-details"> 
                                            <div class="input-group">
                                            <div class="input-details row-group2">
                                                <span class="details">Mật khẩu cũ</span>
                                                <input type="password" placeholder="" required>
                                            </div>
                                            <div class="input-details row-group2">
                                                <span class="details">Mât khẩu mới</span>
                                                <input type="password" placeholder="" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="button">
                                        <input type="submit" value="Xác Nhận">
                                    </div>
                                </form>
                            </div>
                        </div> 
                        </div>
                </div><?php /**PATH E:\xampp\htdocs\citizenv\resources\views/content/changepassword.blade.php ENDPATH**/ ?>